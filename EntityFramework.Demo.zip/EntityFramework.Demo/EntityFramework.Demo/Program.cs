﻿using System;

namespace EntityFramework.Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            var context = new EmployeeContext
                ("Data Source=DESKTOP-SP0OEIJ\SQLEXPRESS;Initial Catalog=TimeManagement;Integrated Security=True")
            var provider = new EmployeeProvider(new EmployeeContext(context));
            var employee = provider.Get(1);
            Console.WriteLine($"Welcome {employee.FirstName} {employee.LastName}");

            var repo = new EmployeeRepo(context);
            var employee1 = provider.Get(2);

            // repo.Create("First", "Last", "Address", "12345", "67890");

            //employee1.FirstName = "NewFirst";     
            //repo.Update(employee1);

            repo.Delate(employee1);
        }
    }
}
